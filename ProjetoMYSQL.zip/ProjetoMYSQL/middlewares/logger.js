import fs from 'fs';

const logger = (req, res, next) => {
    const data = new Date();
    const logMessage = `[${data.toISOString()}] ${req.method} ${req.url}\n`;

    fs.appendFile('acessos.log', logMessage, (err) => {
        if (err) {
            console.error('Erro ao escrever no log:', err);
        }
    });

    console.log(logMessage); 
    next(); 
};

export default logger;
