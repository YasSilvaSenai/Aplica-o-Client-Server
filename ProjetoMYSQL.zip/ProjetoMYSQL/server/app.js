import express from 'express';
import fs from 'fs';
import mysql from 'mysql2'
import logger from '../middlewares/logger.js'; 

const app = express();

app.use(logger);
const port = 3000;

// Configuração do MySQL
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'filmes',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

app.use(express.json());

// Rota para listar todos os filmes 
app.get('/filmes', async (req, res) => {
    try {
        const [rows] = await pool.promise().query('SELECT * FROM filmes');
        res.status(200).json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).send('Erro ao obter filmes.');
    }
});

// Rota para obter filme específico
app.get('/filmes/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const [rows] = await pool.promise().query('SELECT * FROM filmes WHERE id = ?', [id]);
        if (rows.length > 0) {
            res.status(200).json(rows[0]);
        } else {
            res.status(404).send('Filme não encontrado!');
        }
    } catch (err) {
        console.error(err);
        res.status(500).send('Erro ao obter filme!');
    }
});

// Rota para criar um novo filme
app.post('/filmes', async (req, res) => {
    const { titulo, ano, genero, duração } = req.body; 
    if (!titulo || !ano || !genero || !duração) {
        return res.status(400).send('Todos os campos são obrigatórios!');
    }
    try {
        const [result] = await pool.promise().query('INSERT INTO filmes (titulo, ano, genero, duração) VALUES (?, ?, ?, ?)', [titulo, ano, genero, duração]);
        res.status(201).json({ id: result.insertId, titulo, ano, genero, duração });
    } catch (err) {
        console.error(err);
        res.status(500).send('Erro ao criar filme!');
    }
});

// Rota para atualizar um filme
app.put('/filmes/:id', async (req, res) => {
    const { id } = req.params;
    const { titulo, ano, genero, duração } = req.body;
    try {
        const [result] = await pool.promise().query('UPDATE filmes SET titulo = ?, ano = ?, genero = ?, duração = ? WHERE id = ?', [titulo, ano, genero, duração, id]);
        if (result.affectedRows > 0) {
            res.status(200).json({ id, titulo, ano, genero, duração }); 
        } else {
            res.status(404).send('Filme não encontrado.');
        }
    } catch (err) {
        console.error(err);
        res.status(500).send('Erro ao atualizar o filme!');
    }
});

// Rota para deletar um filme
app.delete('/filmes/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const [result] = await pool.promise().query('DELETE FROM filmes WHERE id = ?', [id]);
        if (result.affectedRows > 0) {
            res.status(200).send({ id }); 
        } else {
            res.status(404).send('Filme não encontrado!');
        }
    } catch (err) {
        console.error(err);
        res.status(500).send('Erro ao deletar filme.');
    }
});

app.get('/', (req, res) => {
    res.status(200).send('Página inicial - Filmes 🎞️');
});


app.listen(port, () => {
    console.log(`Servidor em http://localhost:${port}`);
});


