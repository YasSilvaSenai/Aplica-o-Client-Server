import axios from 'axios';
import inquirer from 'inquirer';
import chalk from 'chalk';

const API_URL = 'http://localhost:3000';

async function listarFilmes() {
    try {
        const response = await axios.get(`${API_URL}/filmes`);
        return response.data;
    } catch (error) {
        console.log(chalk.bgRed(`Erro ao listar filmes: ${error.message}`));
        return [];
    }
}

async function exibirFilme(id) {
    try {
        const response = await axios.get(`${API_URL}/filmes/${id}`);
        return response.data;
    } catch (error) {
        console.log(chalk.bgRed(`Erro ao exibir o filme com ID ${id}: ${error.message}`));
    }
}

async function criarFilme(filme) {
    try {
        const response = await axios.post(`${API_URL}/filmes`, filme);
        return response.data;
    } catch (error) {
        console.log(chalk.bgRed(`Erro ao criar o filme: ${error.response?.data || error.message}`));
    }
}

async function atualizarFilme(id, filme) {
    try {
        const response = await axios.put(`${API_URL}/filmes/${id}`, filme);
        return response.data;
    } catch (error) {
        console.log(chalk.bgRed(`Erro ao atualizar o filme com ID ${id}: ${error.message}`));
    }
}

async function removerFilme(id) {
    try {
        await axios.delete(`${API_URL}/filmes/${id}`);
        console.log(chalk.green(`Filme com ID ${id} removido com sucesso!`));
    } catch (error) {
        console.log(chalk.bgRed(`Erro ao remover o filme com ID ${id}: ${error.message}`));
    }
}

async function exibirMenu() {
    const perguntas = [
        {
            type: 'list',
            name: 'opcao',
            message: chalk.yellow('Escolha uma opção: '),
            choices: [
                { name: chalk.green('Listar Filmes'), value: 'listar' },
                { name: chalk.green('Exibir Detalhes de um Filme'), value: 'exibir' },
                { name: chalk.green('Criar um Novo Filme'), value: 'criar' },
                { name: chalk.green('Atualizar um Filme'), value: 'atualizar' },
                { name: chalk.green('Remover um Filme'), value: 'remover' },
                { name: chalk.bgRed('Sair'), value: 'sair' }
            ]
        }
    ];

    const resposta = await inquirer.prompt(perguntas);

    switch (resposta.opcao) {
        case 'listar':
            const filmes = await listarFilmes();
            if (filmes && filmes.length > 0) {
                filmes.forEach(filme => {
                    console.log(`- ${chalk.cyan.bold(filme.id)}: ${chalk.blue.bold(filme.titulo)} Ano: (${chalk.bgCyan.bold(filme.ano)}) Gênero: ${chalk.cyan.bold(filme.genero)} Duração: ${chalk.white.bold(filme.duração)}`);
                });
            } else {
                console.log(chalk.yellow('Nenhum filme encontrado.'));
            }
            break;

        case 'exibir':
            const { id } = await inquirer.prompt([
                { type: 'input', name: 'id', message: chalk.blue('Digite o ID do filme: ') }
            ]);
            const filme = await exibirFilme(id);
            if (filme) {
                console.log(`- Filme: ${chalk.cyan.bold(filme.titulo)}`);
                console.log(`- Gênero: ${chalk.bold.blue(filme.genero)}`);
                console.log(`- Duração: ${chalk.green.bold(filme.duração)}`);
                console.log(`- Ano: ${chalk.yellow.bold(filme.ano)}`);
            } else {
                console.log(chalk.yellow('Filme não encontrado.'));
            }
            break;

        case 'criar':
            const novoFilme = await inquirer.prompt([
                { type: 'input', name: 'titulo', message: chalk.blue('Título do Filme: ') },
                { type: 'input', name: 'ano', message: chalk.blue('Ano: ') },
                { type: 'input', name: 'genero', message: chalk.blue('Gênero: ') },
                { type: 'input', name: 'duração', message: chalk.blue('Duração: ') } 
            ]);

            console.log(novoFilme); 
            await criarFilme(novoFilme);
            console.log(chalk.green('Filme criado e adicionado no banco de dados com sucesso!'));
            break;

        case 'atualizar':
            const { idAtualizar } = await inquirer.prompt([
                { type: 'input', name: 'idAtualizar', message: chalk.blue('Digite o ID do filme a ser atualizado: ') }
            ]);
            const filmeAtualizado = await inquirer.prompt([
                { type: 'input', name: 'titulo', message: chalk.blue('Novo Título do Filme: ') },
                { type: 'input', name: 'ano', message: chalk.blue('Novo Ano: ') },
                { type: 'input', name: 'genero', message: chalk.blue('Novo Gênero: ') },
                { type: 'input', name: 'duração', message: chalk.blue('Nova Duração: ') } 
            ]);
            await atualizarFilme(idAtualizar, filmeAtualizado);
            console.log(chalk.green('Filme atualizado com sucesso!'));
            break;

        case 'remover':
            const { idRemover } = await inquirer.prompt([
                { type: 'input', name: 'idRemover', message: chalk.blue('Digite o ID do filme a ser removido: ') }
            ]);
            await removerFilme(idRemover);
            break;

        case 'sair':
            console.log(chalk.blue('Você saiu!'));
            break;
    }

    if (resposta.opcao !== 'sair') {
        exibirMenu();  
    }
}

exibirMenu();
